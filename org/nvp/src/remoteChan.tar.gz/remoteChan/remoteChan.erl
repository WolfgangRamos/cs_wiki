-module(remoteChan).
-export([newChan/0,chanRegister/3,chanLookup/2,readChan/1,writeChan/2,serialize/1]).

newChan() -> {ok,LSock} = gen_tcp:listen(0,[list,{packet,line}]),
             {ok,Port} = inet:port(LSock),
             Chan = {localChan,spawn(fun() -> chan() end),
                     net_adm:localhost(),Port},
             spawn(fun() -> portListener(LSock,Chan) end),
             Chan.

portListener(LSock,Chan) ->
  case gen_tcp:accept(LSock) of
    {ok,Sock} ->
      receive
        {tcp,Sock,MsgStr} ->
          {remoteMsg,Msg} = deserialize(MsgStr),
          writeChan(Chan,Msg),
          gen_tcp:close(Sock),
          portListener(LSock,Chan)
      end
  end.

chanRegister(Host,Name,{localChan,_,IP,Port}) ->
  case gen_tcp:connect(Host,5042,[list,{packet,line},{active,false}]) of
    {ok,Sock} -> gen_tcp:send(Sock,"store,"++Name++","++serialize({remoteChan,IP,Port})++"\n"),
                 gen_tcp:close(Sock);
    Other     -> base:printLn("chanRegister error: "++base:show(Other))
  end.

chanLookup(Host,Name) ->
  case gen_tcp:connect(Host,5042,[list,{packet,line},{active,false}]) of
    {ok,Sock} -> gen_tcp:send(Sock,"lookup,"++Name++"\n"),
                 case gen_tcp:recv(Sock,0) of
                   {ok,MaybeRemoteChanStr} -> gen_tcp:close(Sock),
                                              deserialize(MaybeRemoteChanStr);
                   Other -> base:printLn("Received unknown value: "++base:show(Other))
                 end
  end.

chan() ->
  receive
    {read,P} -> receive
                  {write,Msg} -> P!{chanMsg,Msg},
                                 chan()
                end
  end.

readChan({localChan,P,_,_}) ->
  P!{read,self()},
  receive
    {chanMsg,Msg} -> Msg
  end.

writeChan({localChan,P,_,_},Msg) ->
  P!{write,Msg};
writeChan({remoteChan,Host,Port},Msg) ->
  case gen_tcp:connect(Host,Port,[list,{packet,line},{active,false}]) of
    {ok,Sock} ->
      gen_tcp:send(Sock,serialize({remoteMsg,Msg})++"\n"),
      gen_tcp:close(Sock)
  end.

serialize({localChan,_,Host,Port}) -> serialize({remoteChan,Host,Port});
serialize(X) when is_atom(X) -> atom_to_list(X);
serialize(X) when is_integer(X) -> integer_to_list(X);
serialize(X) when is_pid(X) -> pid_to_list(X);
serialize(X) when is_tuple(X) -> "{"++serializeList(tuple_to_list(X))++"}";
serialize(X) when is_list(X) -> "["++serializeList(X)++"]".

serializeList([]) -> "";
serializeList([X|Xs]) -> serialize(X)++case Xs of
                                         [] -> "";
                                         _ -> ","++serializeList(Xs)
                                       end.

deserialize(Str) ->
  {ok,Tokens,_EndLine} = erl_scan:string(Str++"."),
  {ok,AbsForm} = erl_parse:parse_exprs(Tokens),
  {value,Value,_Bs} = erl_eval:exprs(AbsForm, erl_eval:new_bindings()),
  Value.




