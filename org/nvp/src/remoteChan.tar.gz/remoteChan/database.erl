-module(database).
-export([start/0]).

start() -> spawn(fun() -> database([]) end).

database(KVs) -> 
  receive
    {store,Key,V,P} -> 
       case base:lookup(Key,KVs) of
         nothing  -> P!success,
                     database([{Key,V}|KVs]);
         {just,_} -> P!success,
                     database([{Key,V}|KVs])
       end;
    {lookup,Key,P} -> P!base:lookup(Key,KVs),
                      database(KVs)
  end.


                      
