-module(pingpong).
-export([ping/0,startPing/0]).
-import(remoteChan,[newChan/0,chanRegister/3,chanLookup/2,readChan/1,
                    writeChan/2,serialize/1]).

startPing() -> Chan = newChan(),
               chanRegister("localhost","ping",Chan),
               pingLoop(Chan,0).

pingLoop(Chan,N) -> 
  case readChan(Chan) of
    {ping,AnsChan} -> writeChan(AnsChan,{pong,N}),
                      pingLoop(Chan,N+1)
  end.

ping() ->
  case chanLookup("localhost","ping") of
    nothing -> base:printLn("ping-service not available");
    {just,Chan} -> AnsChan = newChan(),
                   writeChan(Chan,{ping,AnsChan}),
                   case readChan(AnsChan) of
                     {pong,N} -> {pong,N};
                     Oth  -> base:printLn("Unknown readChan result: "++base:show(Oth))  
                   end;
    Oth  -> base:printLn("Unknown chanLookup result: "++base:show(Oth))  
  end.
                   
