-module(database).
-export([start/0]).

start() -> spawn(fun() -> database([]) end).

database(KVs) -> 
  receive
    {store,Key,V} -> database([{Key,V}|KVs]); 
    {lookup,Key,P} -> P!fac:lookup(Key,KVs),
                      database(KVs)
  end.


                      
