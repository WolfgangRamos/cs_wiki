-module(chatClient).
-export([joinChat/2]).
-import(base,[printLn/1,getLn/1]).

joinChat(Name,ServerNode) ->
  {chat,ServerNode}!{login,Name,self()},
  receive
    {welcome,Names,Server} -> printLn(Names),
                              Me = self(),
                              spawn_link(fun() -> user_input(Server, Name, Me) end),
                              client_loop();
    name_occupied -> printLn("Name bereits vergeben")
  after 2000 -> printLn("Keine Verbindung") 
  end.

client_loop() ->
  receive
    {login,Name}  -> printLn(Name++" hat den Chat betreten."),
                     client_loop();
    {logout,Name} -> printLn(Name++" hat den Chat verlassen."),
                     client_loop();
    {message,Msg,Name} -> printLn(Name++": "++Msg),
                          client_loop()
  end.

user_input(Server, Name, Client) ->
  Str = getLn(Name++"> "),
  case Str of
    "bye" -> Server!{logout,Client},
             exit(42);
    _     -> Server!{message,Str,Client},
             user_input(Server, Name, Client)
  end.

  
