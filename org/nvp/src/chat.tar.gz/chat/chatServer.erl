-module(chatServer).
-export([start/0]).
-import(base,[lookup/2, printLn/1, show/1]).
-import(lists,[map/2]).

start() -> process_flag(trap_exit,true),
           register(chat,self()),
           server_loop([]).


server_loop(Clients) ->
  receive
    {login,Name,P} -> case lookup(Name,Clients) of
                        nothing -> link(P),
                                   P!{welcome,map(fun({X,_}) -> X end, Clients),
                                      self()},
                                   broadcast(Clients,{login,Name},73),
                                   server_loop([{Name,P}|Clients]);
                        {just,_} -> P!name_occupied,
                                    server_loop(Clients)
                      end;
    {logout,P} -> case lists:keyfind(P,2,Clients) of
                    false    -> server_loop(Clients); 
                    {Name,_} -> NewClients = lists:keydelete(P,2,Clients),
                                broadcast(NewClients,{logout,Name},73),
                                server_loop(NewClients)
                  end;
    {message,Msg,P} -> 
        case lists:keyfind(P,2,Clients) of
          false    -> server_loop(Clients); 
          {Name,_} -> broadcast(Clients,{message,Msg,Name},P),
                      server_loop(Clients)
        end;
    {'EXIT',P,Reason} -> base:printLn(Reason),
                         self()!{logout,P},
                         server_loop(Clients);
    Msg -> printLn("Not implemented yet:"++show(Msg)),
           server_loop(Clients)
  end.

broadcast(Clients,Msg,Blind) -> map(fun({_,P}) -> case P==Blind of
                                                    true  -> ok;
                                                    false -> P!Msg
                                                  end
                                    end, Clients).
